<template>
	<div class="search_item">
		<input type="text" name="" placeholder="项目名/客户名/电话">
		<button class="search_btn"><img src="../assets/images/btn-description-search.png"></button>
	</div>
</template>

<script>
	export default {
		
	}
</script>

<style>

</style>
