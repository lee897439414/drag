<template>
	<div class="l_content">
		<div class="left_tips">点右侧“新建项目”</div>
	</div>
</template>

<script>
	export default {
		
	}
</script>

<style>

</style>
