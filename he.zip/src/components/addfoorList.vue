<template>
	<div>
		<div class="map_list">
			<div class="title">已放置点位 <span class="sale_btn"><i class="icon iconfont icon-btn-amount--white-s"></i></span></div>
			<div class="add_all">
				<div class="cont">
					<div class="item">
						<span class="type_item">AP</span>
						<span class="type_name">无线AP</span>
						<span class="type_count">9</span>
					</div>
					<div class="item">
						<span class="type_item">AP</span>
						<span class="type_name">网络电话面板</span>
						<span class="type_count">999</span>
					</div>
					<div class="item">
						<span class="type_item">AP</span>
						<span class="type_name">无线AP</span>
						<span class="type_count">999</span>
					</div>
					<div class="item">
						<span class="type_item">AP</span>
						<span class="type_name">网络电话面板</span>
						<span class="type_count">999</span>
					</div>
					<div class="item">
						<span class="type_item">AP</span>
						<span class="type_name">无线AP</span>
						<span class="type_count">999</span>
					</div>
				</div>
			</div>
		</div>
		<div class="show_btn" style="display: none;">
			<i class="icon iconfont icon-btn-amount-add-ovalb"></i>
		</div>
	</div>
</template>

<script>
	export default {
		data() {
			return {

			};
		}
	}
</script>

<style>

</style>
