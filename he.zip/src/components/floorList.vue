<template>
	<div class="foor_list">
		<img src="../assets/images/icon-arrow-left.png" class="arrow_icon">
		<div class="add_floor">
			<div class="floor_list" :class="{active:isactive==index}" v-for="(item,index) in datalist" @click="floorVal(index)">{{item}} <span class="close" @click="deleteFn(index)"></span></div>
			<div class="add_btn">
				<img src="../assets/images/btn-amount-add-14-pt-gray-1.png">
				<span>添加</span>
			</div>
			<div class="editor">修改楼层名称</div>
		</div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				isactive:0,
				datalist:['1层','2层','3层','4层','5层','6层']
			};
		},
		methods:{
			// 点击楼层
			floorVal(index){
				this.isactive = index
				this.$emit('floorVal','传值了')
				console.log('楼层点击了')
			},
			// 删除楼层
			deleteFn(index){
				this.datalist.splice(index,1)
			}
			
		}
	}
</script>

<style>
</style>
