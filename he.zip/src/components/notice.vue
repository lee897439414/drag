<template>
	<div class="ring">
		<span>10</span>
	</div>
</template>

<script>
	export default {
		
	}
</script>

<style>

</style>
