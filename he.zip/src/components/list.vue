<template>
	<div class="l_content">
		<div class="margin_box clearfix">
			<div class="list_item " :class="{'march':item.statue=='进行中','test':item.statue=='测试','complete':item.statue=='已成交','faild':item.statue=='失败'}" v-for="(item,index) in mylist">
				<div class="list_box">
					<div class="list_title">{{item.title}}</div>
					<div class="right_tip">
						<div class="order_item">No.{{item.No}}</div>
						<div class="test_btn" @click="stClick(index)">{{item.statue}}</div>
						<div class="show_toast" v-if="oindex==index">
							<div class="t_item" @click="textv(item,index,'1')">进行中</div>
							<div class="t_item" @click="textv(item,index,'2')">测试</div>
							<div class="t_item" @click="textv(item,index,'3')">已成交</div>
							<div class="t_item" @click="textv(item,index,'4')">失败</div>
						</div>
					</div>
				</div>
				<router-link class="item_a" :to="{name:'Detail'}">
					<div class="detail_item">
						<div class="item_name">客户姓名:</div>
						<div class="item_right">{{item.name}}</div>
					</div>
					<div class="detail_item">
						<div class="item_name">客户电话: </div>
						<div class="item_right">{{item.tel}}</div>
					</div>
					<div class="detail_item">
						<div class="item_name">客户地址: </div>
						<div class="item_right">{{item.address}}</div>
					</div>
				</router-link>
				<div class="editor_box">
					<span class="read"></span>
					<span class="share"></span>
					<span class="editor"></span>
					<span class="delete" @click="hdelete(index)"></span>
					<span class="c_time">创建：{{item.time}}</span>
				</div>
				
			</div>
			
		</div>
		
	</div>

</template>

<script>
	export default {
		data() {
			return {
				oindex:-1,
				mylist:[
						{
							'ismarch':'测试',
							"title": "测试内容",
							"No": 1,
							"statue": "测试",
							"name": "张三",
							"tel": 138767415634,
							"address": "南宁市徐汇区钦州北路**号**号楼*楼",
							"time": "2017.09.19"
						},
						{
							'ismarch':'测试',
							"title": "我得订单",
							"No": 2,
							"statue": "测试",
							"name": "李四",
							"tel": 138767415634,
							"address": "上海市徐汇区钦州北路**号**号楼*楼",
							"time": "2017.09.19"
						},
						{
							'ismarch':'测试',
							"title": "项目哦",
							"No": 3,
							"statue": "测试",
							"name": "王五",
							"tel": 138767415634,
							"address": "上海市徐汇区钦州北路**号**号楼*楼",
							"time": "2017.09.19"
						},
					]
			}
				
			
		},
		methods:{
			// 点击状态
			stClick(index){
				 this.oindex==index?this.oindex=-1:this.oindex=index
			},
			// 删除订单
			hdelete(index){
				this.mylist.splice(index,1)
			},
			// 修改状态
			textv(item,index,val){
				this.oindex=-1
				switch(val){
					case '1':
						val = '进行中'
						this.statue=val
						break
					case '2':
						val = '测试'
						this.statue=val
						break
					case '3':
						val = '已成交'
						this.statue=val
						break
					case '4':
						val = '失败'
						this.statue=val
						break
				}
				item.statue = val
			}
		},
		
	}
</script>

<style>
	.right_tip{
		position: relative;
	}
	.list_item .show_toast{right:-90px;}
	.t_item,.read,.share,.editor,.delete{cursor: pointer;}
	.main_content .list_item.march{
		background: #f9fbff url(../assets/images/seal-1.png) no-repeat bottom right;
	}
	.main_content .list_item.test{
		background: #f9fbff url(../assets/images/seal-2.png) no-repeat bottom right;
	}
	.main_content .list_item.complete{
		background: #f9fbff url(../assets/images/seal-3.png) no-repeat bottom right;
	}
	.main_content .list_item.faild{
		background: #f9fbff url(../assets/images/seal-4.png) no-repeat bottom right;
	}
</style>
