<template>
	<div class="center_nav">
		<div class="c_title">功能分类 <span class="info">(选图标放置点位)</span></div>
		<div class="type_list">
			<div class="item ">
				<div class="top_title " :class="{active:netWorkchild}" @click="muenueactive">
					<i class="icon iconfont icon-left-menu-icon--x-8"></i>网络覆盖 <span class="add_count" v-if="count>0">{{count}}</span>
				</div>
				<div class="olist" v-show="netWorkchild">
					<div class="item_box">
						<div class="t_list" :class="{active:index==itemIndex}" v-for="(item,index) in netWork" @click="listActive(index)">
							<img src="../assets/images/btn-checkbox-1-oval-blue@3x.png" width="24" height="24">
							<div class="t_name">{{item.name}}</div>
							<div class="t_sum">0</div>
						</div>
					</div>
				</div>
			</div>
			<div class="item">
				<div class="top_title" :class="{active:fardArrChild}" @click="fardVideo">
					<i class="icon icon iconfont icon-left-menu-icon--x-"></i>远程监控  <span class="add_count" v-if="fardCount>0">{{fardCount}}</span>
				</div>
				<div class="olist" v-show="fardArrChild">
					<div class="item_box">
						<div class="t_list" :class="{active:index==fardIndex}" v-for="(item,index) in fardArr" @click="fardActive(index)">
							<img src="../assets/images/btn-checkbox-1-oval-blue@3x.png" width="24" height="24">
							<div class="t_name">{{item.name}}</div>
							<div class="t_sum">0</div>
						</div>
					</div>
				</div>
			</div>
			<div class="item">
				<div class="top_title" :class="{active:saftArrChild}" @click="saftTitle">
					<i class="icon iconfont icon-left-menu-icon--x-1"></i>安防感应 <span class="add_count" v-if="fardCount>0">{{saftCount}}</span>
				</div>
				<div class="olist" v-show="saftArrChild">
					<div class="item_box">
						<div class="t_list" :class="{active:index==saftIndex}" v-for="(item,index) in saftArr" @click="saftActive(index)">
							<img src="../assets/images/btn-checkbox-1-oval-blue@3x.png" width="24" height="24">
							<div class="t_name">{{item.name}}</div>
							<div class="t_sum">0</div>
						</div>
					</div>
				</div>
			</div>
			<div class="item">
				<div class="top_title" :class="{active:musicArrChild}" @click="musicTitle">
					<i class="icon iconfont icon-left-menu-icon--x-2"></i>背景音乐 <span class="add_count" v-if="musicCount>0">{{musicCount}}</span>
				</div>
				<div class="olist" v-show="musicArrChild">
					<div class="item_box">
						<div class="t_list" :class="{active:index==musicIndex}" v-for="(item,index) in musicArr" @click="musicActive(index)">
							<img src="../assets/images/btn-checkbox-1-oval-blue@3x.png" width="24" height="24">
							<div class="t_name">{{item.name}}</div>
							<div class="t_sum">0</div>
						</div>
					</div>
				</div>
			</div>
			<div class="item">
				<div class="top_title" :class="{active:curtainsArrChild}" @click="curtainsTitle">
					<i class="icon iconfont icon-left-menu-icon--x-4"></i>电动窗帘 <span class="add_count" v-if="fardCount>0">{{curtainsCount}}</span>
				</div>
				<div class="olist" v-show="curtainsArrChild">
					<div class="item_box">
						<div class="t_list" :class="{active:index==curtainsIndex}" v-for="(item,index) in curtainsArr" @click="curtainsActive(index)">
							<img src="../assets/images/btn-checkbox-1-oval-blue@3x.png" width="24" height="24">
							<div class="t_name">{{item.name}}</div>
							<div class="t_sum">0</div>
						</div>
					</div>
				</div>
			</div>
			<div class="item">
				<div class="top_title" :class="{active:seeArrChild}" @click="seeTitle">
					<i class="icon iconfont icon-left-menu-icon--x-3"></i>可视对讲 <span class="add_count" v-if="fardCount>0">{{seeCount}}</span>
				</div>
				<div class="olist" v-show="seeArrChild">
					<div class="item_box">
						<div class="t_list" :class="{active:index==seeIndex}" v-for="(item,index) in seeArr" @click="seeActive(index)">
							<img src="../assets/images/btn-checkbox-1-oval-blue@3x.png" width="24" height="24">
							<div class="t_name">{{item.name}}</div>
							<div class="t_sum">0</div>
						</div>
					</div>
				</div>
			</div>
			<div class="item">
				<div class="top_title" :class="{active:environmentArrChild}" @click="environmentTitle">
					<i class="icon iconfont icon-left-menu-icon--x-5"></i>环境控制 <span class="add_count" v-if="environmentCount>0">{{environmentCount}}</span>
				</div>
				<div class="olist" v-show="environmentArrChild">
					<div class="item_box">
						<div class="t_list" :class="{active:index==environmentIndex}" v-for="(item,index) in environmentArr" @click="environmentActive(index)">
							<img src="../assets/images/btn-checkbox-1-oval-blue@3x.png" width="24" height="24">
							<div class="t_name">{{item.name}}</div>
							<div class="t_sum">0</div>
						</div>
					</div>
				</div>
			</div>
			<div class="item">
				<div class="top_title" :class="{active:intelligenceArrChild}" @click="intelligenceTitle">
					<i class="icon iconfont icon-left-menu-icon--x-6"></i>智能照明 <span class="add_count" v-if="intelligenceCount>0">{{intelligenceCount}}</span>
				</div>
				<div class="olist" v-show="intelligenceArrChild">
					<div class="item_box">
						<div class="t_list" :class="{active:index==intelligenceIndex}" v-for="(item,index) in intelligenceArr" @click="intelligenceActive(index)">
							<img src="../assets/images/btn-checkbox-1-oval-blue@3x.png" width="24" height="24">
							<div class="t_name">{{item.name}}</div>
							<div class="t_sum">0</div>
						</div>
					</div>
					<div class="type_switch">
						<div class="otitle">
							<div class="switch_tips">以下图标请根据实际需求放置点位</div>
						</div>
						<div class="switch_main">
							<div class="switch_title" :class="{active:countSwitch}" @click="switchFn">总线开关回路 <span class="s_icon"></span> <span class="count fr">0</span></div>
							<div class="switch_title_list" v-if="resicleArr.length>0">
								<div class="sw_list clearfix" >
									<div class="s_item fl" v-for="(index,itemm) in resicleArr">
										<div class="s_img">
											<img src="../assets/images/btn-checkbox-3-oval-blue-selected@3x.png" width="26" height="26">
										</div>
										<div class="s_name">1路</div>
									</div>
									
								</div>
							</div>
						</div>
						<div class="switch_main">
							<div class="switch_title" :class="{active:countLight}" @click="totalFn">总线调光回路 <span class="s_icon"></span><span class="count fr">0</span></div>
							<div class="switch_title_list" v-if="lighteArr.length>0">
								<div class="sw_list clearfix">
									<div class="s_item fl" v-for="(index,item) in lighteArr">
										<div class="s_img">
											<img src="../assets/images/btn-checkbox-3-oval-blue-selected@3x.png" width="26" height="26">
										</div>
										<div class="s_name">1路</div>
									</div>
									
								</div>
							</div>
						</div>
						<div class="switch_main">
							<div class="switch_title" :class="{active:tenSwitch}" @click="tenFn">总线0-10V调光回路 <span class="s_icon"></span><span class="count fr">0</span></div>
							<div class="switch_title_list" style="display: none;">
								<div class="sw_list clearfix">
									<div class="s_item fl">
										<div class="s_img">
											<img src="../assets/images/btn-checkbox-3-oval-blue-selected@3x.png" width="26" height="26">
										</div>
										<div class="s_name">1路</div>
									</div>
									
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="item">
				<div class="top_title" :class="{active:homeArrChild}" @click="homeTitle">
					<i class="icon iconfont icon-left-menu-icon--x-7"></i>家庭影院 <span class="add_count" v-if="homeCount>0">{{homeCount}}</span>
				</div>
				<div class="olist" v-show="homeArrChild">
					<div class="item_box">
						<div class="t_list" :class="{active:index==homeIndex}" v-for="(item,index) in homeArr" @click="homeActive(index)">
							<img src="../assets/images/btn-checkbox-1-oval-blue@3x.png" width="24" height="24">
							<div class="t_name">{{item.name}}</div>
							<div class="t_sum">0</div>
						</div>
					</div>
				</div>
			</div>
			<div class="item">
				<div class="top_title" :class="{active:controlArrChild}" @click="controlTitle">
					<i class="icon iconfont icon-left-menu-icon--x-9"></i>智能中控 <span class="add_count" v-if="controlCount>0">{{controlCount}}</span>
				</div>
				<div class="olist" v-show="controlArrChild">
					<div class="item_box">
						<div class="t_list" :class="{active:index==controlIndex}" v-for="(item,index) in controlArr" @click="controlActive(index)">
							<img src="../assets/images/btn-checkbox-1-oval-blue@3x.png" width="24" height="24">
							<div class="t_name">{{item.name}}</div>
							<div class="t_sum">0</div>
						</div>
					</div>
					
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				count: 0, //网络覆盖总数量
				fardCount: 0, //远程监控总数量
				saftCount: 0, //远程监控总数量
				musicCount: 0, 
				curtainsCount: 0, 
				seeCount: 0, 
				environmentCount: 0, 
				intelligenceCount: 0, 
				homeCount: 0, 
				controlCount: 0, 
				netWork: [],//网络覆盖
				netWorkchild: false, //显示隐藏大分类下的子分类
				itemIndex: -1, //网络覆盖点击功能分类，下的子分类选中控制
				fardArr:[],//远程监控
				fardArrChild:false,//远程监控子分类显示
				fardIndex: -1, //网络覆盖点击功能分类，下的子分类选中控制
				saftArr:[],//安防感应
				saftIndex: -1,
				saftArrChild:false,
				musicArr:[],//背景音乐
				musicArrChild:false,
				musicIndex: -1,
				curtainsArr:[],//电动窗帘
				curtainsArrChild:false,
				curtainsIndex: -1,
				seeArr:[],//可视对讲
				seeArrChild:false,
				seeIndex: -1,
				environmentArr:[],//环境控制
				environmentArrChild:false,
				environmentIndex: -1,
				intelligenceArr:[],//智能照明
				intelligenceArrChild:false,
				intelligenceIndex: -1,
				homeArr:[],//家庭影院
				homeArrChild:false,
				homeIndex: -1,
				controlArr:[],//智能中控
				controlArrChild:false,
				controlIndex: -1,
				resicleArr:[],//总线开关回路
				lighteArr:[],// 总线调光回路
				lighteRArr:[],// 总线0-10V调光回路
				countSwitch:false,//总线开关回路点击
				countLight:false,//总线调光回路点击
				tenSwitch:false,//总线0-10V调光回路点击
			};
		},
		created() {
			this.getDataFn()
		},
		methods: {
			// 点击总线开关
			switchFn(){
				this.countSwitch = true
				this.countLight = false
				this.tenSwitch = false
			},
			// 总线调光回路点击
			totalFn(){
				this.countSwitch = false
				this.countLight = true
				this.tenSwitch = false
			},
			// 总线0-10V调光回路点击
			tenFn(){
				this.countSwitch = false
				this.countLight = false
				this.tenSwitch =true 
			},
			getDataFn() {
				let that = this
				this.$http({
					method: 'GET',
					url: 'http://app.oneapptech.cn/index.php?m=Api&c=goods&a=goodsCategoryInfo',

				}).then((response) => { //接口返回数据
					let data = response.data
					let result = data.result
					result.forEach(function(value, index, array) {
						if (array[index].parent_id == 845) {
							that.netWork.push(array[index])
						}
						if (array[index].parent_id == 922) {
							that.netWork.push(array[index])
						}
						if(array[index].parent_id == 849){
							that.fardArr.push(array[index])
						}
						if(array[index].parent_id == 850){
							that.saftArr.push(array[index])
						}
						if(array[index].parent_id == 851){
							that.musicArr.push(array[index])
						}
						if(array[index].parent_id == 852){
							that.curtainsArr.push(array[index])
						}
						if(array[index].parent_id == 853){
							that.seeArr.push(array[index])
						}
						if(array[index].parent_id == 854){
							that.environmentArr.push(array[index])
						}
						if(array[index].parent_id == 855){
							that.intelligenceArr.push(array[index])
						}
						if(array[index].parent_id == 856){
							that.controlArr.push(array[index])
						}
						if(array[index].parent_id == 857){
							that.homeArr.push(array[index])
						}
						if(array[index].parent_id == 913){
							that.resicleArr.push(array[index])
						}
						if(array[index].parent_id == 914){
							that.lighteArr.push(array[index])
						}
						if(array[index].parent_id == 915){
							that.lighteRArr.push(array[index])
						}
					})
					console.log(that.lighteRArr)
				})
			},
			//显示隐藏大分类下的子分类
			muenueactive() {
				this.fardArrChild = false
				this.saftArrChild = false
				this.musicArrChild = false
				this.curtainsArrChild =false
				this.seeArrChild = false
				this.environmentArrChild =false
				this.intelligenceArrChild = false
				this.homeArrChild = false
				this.controlArrChild =false
				this.netWorkchild = !this.netWorkchild
			},
			listActive(index) {
				this.itemIndex = index
			},
			//点击远程监控
			fardVideo(){
				this.netWorkchild =false
				this.saftArrChild = false
				this.musicArrChild = false
				this.curtainsArrChild =false
				this.seeArrChild = false
				this.environmentArrChild =false
				this.intelligenceArrChild = false
				this.homeArrChild = false
				this.controlArrChild =false
				this.fardArrChild = !this.fardArrChild
				
			},
			fardActive(index) {
				this.fardIndex = index
			},
			// 安防感应
			saftTitle(){
				this.fardArrChild = false
				this.netWorkchild =false
				this.musicArrChild = false
				this.curtainsArrChild =false
				this.seeArrChild = false
				this.environmentArrChild =false
				this.intelligenceArrChild = false
				this.homeArrChild = false
				this.controlArrChild =false
				this.saftArrChild = !this.saftArrChild
			},
			saftActive(index) {
				this.saftIndex = index
			},
			// 背景音乐
			musicTitle(){
				this.fardArrChild = false
				this.netWorkchild =false
				this.saftArrChild = false
				this.curtainsArrChild =false
				this.seeArrChild = false
				this.environmentArrChild =false
				this.intelligenceArrChild = false
				this.homeArrChild = false
				this.controlArrChild =false
				this.musicArrChild = !this.musicArrChild
			},
			musicActive(index) {
				this.musicIndex = index
			},
			// 电动窗帘
			curtainsTitle(){
				this.fardArrChild = false
				this.netWorkchild =false
				this.saftArrChild = false
				this.musicArrChild = false
				this.seeArrChild = false
				this.environmentArrChild =false
				this.intelligenceArrChild = false
				this.homeArrChild = false
				this.controlArrChild =false
				this.curtainsArrChild = !this.curtainsArrChild
			},
			curtainsActive(index) {
				this.curtainsIndex = index
			},
			//可视对讲
			seeTitle(){
				this.fardArrChild = false
				this.netWorkchild =false
				this.saftArrChild = false
				this.musicArrChild = false
				this.curtainsArrChild = false
				this.environmentArrChild =false
				this.intelligenceArrChild = false
				this.homeArrChild = false
				this.controlArrChild =false
				this.seeArrChild = !this.seeArrChild
			},
			seeActive(index) {
				this.seeIndex = index
			},
			//环境控制environment
			environmentTitle(){
				this.fardArrChild = false
				this.netWorkchild =false
				this.saftArrChild = false
				this.musicArrChild = false
				this.curtainsArrChild = false
				this.seeArrChild = false
				this.intelligenceArrChild = false
				this.homeArrChild = false
				this.controlArrChild =false
				this.environmentArrChild = !this.environmentArrChild
			},
			environmentActive(index) {
				this.environmentIndex = index
			},
			//智能照明
			intelligenceTitle(){
				this.fardArrChild = false
				this.netWorkchild =false
				this.saftArrChild = false
				this.musicArrChild = false
				this.curtainsArrChild = false
				this.seeArrChild = false
				this.environmentArrChild = false
				this.homeArrChild = false
				this.controlArrChild =false
				this.intelligenceArrChild = !this.intelligenceArrChild
			},
			intelligenceActive(index) {
				this.intelligenceIndex = index
			},
			//家庭影院
			homeTitle(){
				this.fardArrChild = false
				this.netWorkchild =false
				this.saftArrChild = false
				this.musicArrChild = false
				this.curtainsArrChild = false
				this.seeArrChild = false
				this.environmentArrChild = false
				this.intelligenceArrChild = false
				this.controlArrChild =false
				this.homeArrChild = !this.homeArrChild
			},
			homeActive(index) {
				this.homeIndex = index
			},
			// 智能中控
			controlTitle(){
				this.fardArrChild = false
				this.netWorkchild =false
				this.saftArrChild = false
				this.musicArrChild = false
				this.curtainsArrChild = false
				this.seeArrChild = false
				this.environmentArrChild = false
				this.intelligenceArrChild = false
				this.homeArrChild = false
				this.controlArrChild = !this.controlArrChild
			},
			controlActive(index) {
				this.controlIndex = index
			},
		}
	}
</script>

<style>
	.top_title.active {
		color: #00b9e0;
		font-weight: 500;
	}
</style>
