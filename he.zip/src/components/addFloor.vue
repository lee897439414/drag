<template>
	<div class="add_floor_marsk">
		<div class="add_tile">添加楼层<i class="icon iconfont icon-btn-cross-white--"></i></div>
		<div class="add_name">
			<input type="text" name="" class="name_input" placeholder="请输入楼层名称">
		</div>
		<div class="floor_confirn">确定</div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style>

</style>
