<template>
	<div class="history_open">
		<div class="title">最近打开</div>
		<ul class="history_list">
			<li>壹智能别墅X</li>
			<li>壹智能别墅X</li>
			<li>壹智能别墅X</li>
			<li>壹智能别墅X</li>
		</ul>
	</div>
</template>

<script>
	export default {
		
	}
</script>

<style>

</style>
