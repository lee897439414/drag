<template>
	<div class="upload_img">
		<i class="icon iconfont icon-btn-amount-add-line-"></i>
		<div class="text">添加图片</div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		},
		methods:{
			
		}
	}
</script>

<style>

</style>
