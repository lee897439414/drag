<template>
	<div class="left_side">
		<div class="logo"><img src="../assets/images/logo.png"></div>
		<div class="left_item">
			<div class="main_title">
				<i class="icon iconfont icon-title-icon-main"></i>壹智能首页
			</div>
		</div>
		<div class="left_item" :class="id==key? 'active' : ''" v-for="(item,key) in menudata">
			<div class="main_title" @click="oclick(key)">
				<i class="icon iconfont" :class="item.icon"></i>{{item.name}}
			</div>
			<ul class="oul" :style="id==key?'display:block;': ''">
				<li :class="i.id==id2?'active':''"  v-for="i in item.pordata">
				   <span @click="liclick(i.id)">{{i.name}}</span>
				</li>
			</ul>
		</div>
	</div>

</template>

<script>
	export default {
		data() {
			return {
				id: '-1',
				id2:'0',
				isCollapsed: false,
				items: [1, 2, 3, 4],
				menudata: [{
						'id': 2,
						'name': '制图模式',
						'icon': 'icon-title-icon-ztms-blue',
						'to': '',
						'pordata': [
							{
								'id':'2-0',
								'name': '全部项目',
								'icon': '',
								'to': '',
								'pordata': []
							}, {
								'id': '2-1',
								'name': '进行中',
								'icon': '',
								'to': '',
								'pordata': []
							},
							{
								'id':'2-2',
								'name': '测试',
								'icon': '',
								'to': '',
								'pordata': []
							},
							{
								'id': '2-3',
								'name': '已成交',
								'icon': '',
								'to': '',
								'pordata': []
							},
							{
								'id': '2-4',
								'name': '失败',
								'icon': '',
								'to': '',
								'pordata': []
							},
						]
					},
					{
						'id': 3,
						'name': '快速模式',
						'icon': 'icon-title-icon-ksms1',
						'to': '',
						'pordata': [
							{
								'id':' 3-1',
								'name': '全部项目',
								'icon': '',
								'to': '',
								'pordata': []
							}, {
								'id':'3-2',
								'name': '进行中',
								'icon': '',
								'to': '',
								'pordata': []
							},
							{
								'id':'3-3',
								'name': '测试',
								'icon': '',
								'to': '',
								'pordata': []
							},
							{
								'id':'3-4',
								'name': '已成交',
								'icon': '',
								'to': '',
								'pordata': []
							},
							{
								'id':'3-5',
								'name': '失败',
								'icon': '',
								'to': '',
								'pordata': []
							},
						]
					},
					{
						'id': 4,
						'name': '智能模式',
						'icon': 'icon-title-icon-znms',
						'to': '',
						'pordata': [
							{
								'id':'4-1',
								'name': '全部项目',
								'icon': '',
								'to': '',
								'pordata': []
							}, {
								'id':'4-2',
								'name': '进行中',
								'icon': '',
								'to': '',
								'pordata': []
							},
							{
								'id':'4-3',
								'name': '测试',
								'icon': '',
								'to': '',
								'pordata': []
							},
							{
								'id':'4-4',
								'name': '已成交',
								'icon': '',
								'to': '',
								'pordata': []
							},
							{
								'id':'4-5',
								'name': '失败',
								'icon': '',
								'to': '',
								'pordata': []
							},
						]
					},
					{
						'id': 5,
						'name': '管理',
						'icon': 'icon-title-icon-manage',
						'to': '',
						'pordata': [
							{
								'id':'5-1',
								'name': '销售管理',
								'icon': '',
								'to': '',
								'pordata': []
							},
							{
								'id':'5-2',
								'name': '销售项目管理',
								'icon': '',
								'to': '',
								'pordata': []
							},
						]
					},
					{
						'id': 6,
						'name': '通知中心',
						'icon': 'icon-title-icon-notice',
						'to': '',
						'pordata': []
					},

				]
			}
		},

		components: {

		},
		methods: {
			oclick(key) {
				this.id = key
			},
			liclick(key){
				this.id2 = key
			}

		}
	}
</script>

<style>
	.oul {
		display: none;
	}
</style>
