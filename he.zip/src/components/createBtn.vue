<template>
	<div class="creat_btn">
		<img src="../assets/images/btn-amount-add-ovalblue-1.png">
		<span>新建项目</span>
	</div>
</template>

<script>
	export default {
		
	}
</script>

<style>

</style>
