import Vue from 'vue'
import vuex from 'vuex'
Vue.use(vuex);
var store = new vuex.Store({//store对象
    state:{
        isShow:false,
    },
	mutations:{
		myennter(){
			this.state.isShow = true
		},
		myleve(){
			this.state.isShow = false
		},
		// 隐藏弹窗
		hidediv(e){
			console.log(e)
		}
	}
})

export default store