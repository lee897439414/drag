<template>
	<div class="content">
		<leftNav></leftNav>
		<div class="right_side">
			<div class="top_item">
				<!-- 搜索框 -->
				<searchItem></searchItem>
				<!-- 消息提示 -->
				<notice></notice>
				<!-- 用户信息 -->
				<userInfo></userInfo>
			</div>
			<div class="main_content">
				<!-- <showTip></showTip>	 -->
				<listItem></listItem>
				<div class="r_content">
					<creatBtn></creatBtn>
					<!-- 最近打开 -->
					<lately></lately>
					<!-- 最新项目 -->
					<latestProject></latestProject>
				</div>
			</div>
		</div>
		<heConfirm v-show=""></heConfirm>
	</div>
	
</template>

<script>
	import leftNav from '../components/left_nav_f'
	import notice from '../components/notice'
	import searchItem from '../components/search_item'
	import userInfo from '../components/userInfo'
	import showTip from '../components/showTip'
	import creatBtn from '../components/createBtn'
	import lately from '../components/lately'
	import latestProject from '../components/latestProject'
	import listItem from '../components/list'
	import heConfirm from '../components/heConfirm'
	export default {
		components:{
			leftNav,
			notice,
			searchItem,
			userInfo,
			showTip,
			creatBtn,
			lately,
			latestProject,
			listItem,
			heConfirm
		},
		methods:{
			
		}
	}

</script>

<style>
</style>