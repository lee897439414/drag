<template>
	<div>
		<div class="content_dt">
			<div class="d_left_Side">
				<div class="back_item">
					<span class="back"><i class="icon iconfont icon-btn-arrow-left-blue-"></i>返回</span>
					<span class="send" >发送<i class="icon iconfont icon-btn-description-shar"></i></span>
				</div>
				<div class="floor_box">
					<div class="floor_item" @click="show_list()" >
						<span class="floor_title">楼层</span>
						<span class="check_floor" v-on:floorVal="gtfun">{{chooseFloorItem}}</span>
						<i class="icon iconfont icon iconfont icon-btn-description-swit"></i>
					</div>
				</div>
				<centerNav></centerNav>
				<iconSize></iconSize>
				<div class="up_show_item">
					<i class="icon iconfont icon-btn-description-dot-"></i>
					<i class="icon iconfont icon-btn-description-view"></i>
					<i class="icon iconfont icon-btn-description-dot-1"></i>
				</div>
			</div>
			<div class="d_right_Side">
				<!-- 楼层列表 -->
				<FloorList v-show="isshow"></FloorList>
				<!-- 上传图片 -->
				<imgUp></imgUp>
				<!-- 已添加的列表 -->
				<addFloorList></addFloorList>
			</div>
		</div>
		<!-- 添加楼层弹出 -->
		<addFloor style="display: none;"></addFloor>
	</div>
</template>

<script>
	import addFloor from '../components/addFloor'
	import addFloorList from '../components/addfoorList'
	import FloorList from '../components/floorList'
	import imgUp from '../components/uploadIMGbtn'
	import centerNav from '../components/centerNav'
	import iconSize from '../components/iconSize'
	export default {
		data() {
			return {
				isshow:false,
				indexNum:-1,
				chooseFloorItem:'请选择楼层',
				fl:0
			};
		},
		components:{
			addFloor,
			addFloorList,
			FloorList,
			imgUp,
			centerNav,
			iconSize
		},
		methods:{
			// 显示隐藏楼层列表
			show_list(){
				this.isshow = !this.isshow
			},
			gtfun:function(floorVal){
				
				console.log('111111')
			}
// 			gtfun(datalist){
// 				console.log(datalist)
// 			}
			
		}
	}
</script>

<style>

</style>
