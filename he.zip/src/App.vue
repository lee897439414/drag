<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
import oindexLeft from './components/left_nav_f'
export default {
  name: 'App',
  components:{
  	oindexLeft
  }
}
</script>

<style>

</style>
